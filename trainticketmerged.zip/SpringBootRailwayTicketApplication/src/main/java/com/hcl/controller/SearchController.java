package com.hcl.controller;

import java.sql.Date;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.hcl.exception.DetailsNotFoundException;
import com.hcl.service.SearchService;

@RestController
public class SearchController {
	@Autowired
	SearchService searchService;
	@GetMapping("/trains")
	public ResponseEntity<Map> searchtrains( @RequestParam("source") String source,@RequestParam("destination") String destination,@RequestParam("date")Date date) throws DetailsNotFoundException 
	{	
		
		
		 return searchService.gettrains(source, destination, date);
			
		
		
		
	}
}