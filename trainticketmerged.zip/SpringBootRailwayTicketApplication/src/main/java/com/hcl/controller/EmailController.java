package com.hcl.controller;

import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hcl.serviceimpl.EmailServiceImpl;

import net.bytebuddy.utility.RandomString;

@RestController
public class EmailController {
	
	@Autowired 
	EmailServiceImpl emailService;
	@GetMapping("/mail")
    public boolean sendSimpleMessage() {
		
		String otp=RandomString.make(8);
		String to="mahirajain2808@gmail.com";
		String subject="One-Time-Password (OTP)";
		String content="<p>Hello Kanchan </p>"
				+"Here is your One-Time-Password (OTP)"
				+"<p><b>"+ otp +"</b></p>";
		boolean flag=emailService.sendEmail(subject, content, to);
//		if(flag) {
//			System.out.println("send succesfully");
//		}
//		else {
//			System.out.println("did not sent");
//		}
		return flag;
    }

}
