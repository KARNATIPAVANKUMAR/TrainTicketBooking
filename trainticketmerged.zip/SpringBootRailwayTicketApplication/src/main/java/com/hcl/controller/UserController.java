package com.hcl.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.hcl.serviceimpl.UserServiceImpl;

@RestController
public class UserController {
	@Autowired()
	UserServiceImpl userServices;
	
	
	@PostMapping("/users")
	public ResponseEntity<?> sendOtp(String username) {
		return userServices.login(username);
		
	}
	
	@PostMapping("/users/otp")
	public ResponseEntity<String> otpVallidation(@RequestParam int uid,@RequestParam String otp){
		return userServices.otpValidation(uid,otp);
	}

}
