package com.hcl.model;

import javax.persistence.Embeddable;

@Embeddable
public class Passengers {

	private int age;
	private String name;
	private long adhaarNumber;
	private String address;
	private String gender;

	public Passengers() {
		super();
	}

	public Passengers(int age, String name, long adhaarNumber, String address, String gender) {
		super();
		this.age = age;
		this.name = name;
		this.adhaarNumber = adhaarNumber;
		this.address = address;
		this.gender = gender;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public void setAdhaarNumber(long adhaarNumber) {
		this.adhaarNumber = adhaarNumber;
	}
	

	public long getAdhaarNumber() {
		return adhaarNumber;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

}
