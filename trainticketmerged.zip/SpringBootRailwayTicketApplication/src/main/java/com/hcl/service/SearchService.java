package com.hcl.service;

import java.sql.Date;
import java.util.Map;

import org.springframework.http.ResponseEntity;

public interface SearchService {

	

	ResponseEntity<Map> gettrains(String source, String destination, Date date);

}
