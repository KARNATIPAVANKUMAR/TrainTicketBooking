package com.hcl.exception;

public class TicketNotBookedException extends Exception {
	String message;

	public TicketNotBookedException() {
		super();
	}

	public TicketNotBookedException(String message) {
		super(message);
		this.message = message;
	}

}
